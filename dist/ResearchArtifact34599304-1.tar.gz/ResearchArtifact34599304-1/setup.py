from setuptools import setup

setup(
    name='ResearchArtifact34599304',
    version='1',
    packages=[''],
    url='',
    license='',
    author='Freddy Rademeyer',
    author_email='Freddyrad@hotmail.com',
    description='Research Artifact'
)
